#include "mythread.h"


MyThread::MyThread()
{
    m_threadStop = true;
}
